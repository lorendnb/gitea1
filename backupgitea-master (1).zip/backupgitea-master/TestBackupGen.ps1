$ENV:SSH_USER="backupgen";
$ENV:SSH_SERVER="192.168.1.243";
$ENV:SSH_PRIVATEKEYFILE="backupkeygitea"
Invoke-Expression .\backup_gitea.ps1