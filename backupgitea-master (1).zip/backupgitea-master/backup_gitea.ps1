﻿$ErrorActionPreference = "stop"
Invoke-Expression (Join-Path $PSScriptRoot "bkp_utils.ps1");
Invoke-Expression (Join-Path $PSScriptRoot "Tools.ssh.ps1");
$BKP_ITEM = GetEnvVarDef "BKP_ITEM" "Gitea"
$msg = "Backup $BKP_ITEM" + ": Comienzo de backup"
$Global:Verbose = $True;
try {
    CheckEnvVars True ("SSH_PRIVATEKEYFILE", "SSH_USER", "SSH_SERVER");
    if (!(Test-Path $ENV:SSH_PRIVATEKEYFILE)) {
        throw "Error. File $ENV:SSH_PRIVATEKEYFILE does not exist";
    }

    # Directorio de salida en la máquina cliente
    $OUTPUTDIR = GetEnvVarDef "BKP_OUTPUTDIR" "salida"

    # Directorio de trabajo en el host
    $WORKDIR = GetEnvVarDef "BKP_WORKDIR" "backup_gitea"

    # Script de backup en el host. Relativo al directorio de trabajo
    $SCRIPTFILE = GetEnvVarDef "BKP_SCRIPTFILE" "./backup_gitea.sh"

    # Directorio de payload.
    $PAYLOADDIR = GetEnvVarDef "BKP_PAYLOADDIR" "./backup_gitea/data";

    # Archivo con el payload
    # $PAYLOADFILE = GetEnvVarDef "BKP_PAYLOADFILE" "backup_gitea.tar.gz";

    # Chequea que exista el directorio de salida
    CheckDirectoriesExist($OUTPUTDIR);

    $Credentials = MakeSSHCredentials $ENV:SSH_SERVER $ENV:SSH_USER $ENV:SSH_PRIVATEKEYFILE

	# Envia la ultima versión del script de backup.
	EnviarSSH $credentials "backup_gitea.sh" . $WORKDIR
		
    # NOTA: Tiene que desactivar el control de errores porque algunas escrituras a stderr de warnings.
    # Pasa con algunso warnings del mysql.

   	# Calcula el nombre completo del archivo nomenclado	
	$ZipFileName = (CalcularNombre -Entorno "PROD" -Que "BACKUP" -Quien "GITEA" -COMPUTERNAME $Env:COMPUTERNAME);    
	
	$Comando = "'cd $WORKDIR;chmod +x ./$SCRIPTFILE;./$SCRIPTFILE $ZipFileName' 2>error.txt"	
    write-host -foreground cyan $comando
	
    $ErrorActionPreference = "Continue"
    EjecutarSSH $Credentials $Comando
    $ErrorActionPreference = "Stop"

    RecibirSSH $credentials $ZipFileName $PAYLOADDIR $OUTPUTDIR
    
    # Registra en el eventLog.
    $msg = "Backup $BKP_ITEM" + ": El backup ha finalizado OK";
	# Write-EventLog -LogName Application -Source $eventLogSource -EntryType Information -Message $msg -EventId 2;

	write-host -foreground green "El backup se completo de manera exitosa"
}
catch {
    $ex = $_;
    $errorCapture = "";
    if (Test-Path error.txt) {
        $errorCapture = Get-Content error.txt
    }
    $msg = "Backup $BKP_ITEM.Error: " + $ex.ToString();
    if ($errorCapture) {
        $msg = "$msg Error Capture: $errorCapture";
    }
    Write-Host
    Write-host -foreground red "Error: $ex"
    if ($errorCapture) {
        Write-host -foreground red "Error Capture: $errorCapture"
    }
    Exit 2
}
