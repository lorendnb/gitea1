#!/bin/bash

#
# Backupea los directorios del gitlab en el host y los comprime.
# generando una archivo con la fecha.
#

# Setea el modo de error. Si un comando falla, aborta.
set -e

CONTAINERNAME=giteaprod
BASENAME=gitea

# Directorio de backups
SRCDIR=/srv/$BASENAME
bkpdir=data

# Crea el directorio si no existe.
sudo mkdir -p $bkpdir

# calcula el bkpdir como fullpath
pushd $bkpdir
fullbkpdir=$PWD
popd

pushd $SRCDIR

backupname="backup_gitea"

# Crea el tar.gz
sudo tar -cvpzf $fullbkpdir/$backupname.tar.gz *

pushd $fullbkpdir
# Obtiene el nombre de la imagen exacta que estamos usando
IMAGENAME=$(sudo docker ps -f "name=$CONTAINERNAME" --format "{{.Image}}") && echo $IMAGENAME
LINE="export IMAGENAME=$IMAGENAME"
echo $LINE >DockerParams.sh
LINE="export ORIGINALCONTAINERNAME=$CONTAINERNAME"
echo $LINE >>DockerParams.sh


# Zipea el .tar.gz
sudo zip $1 $backupname.tar.gz DockerParams.sh
# Borra el .tar.gz
sudo rm -f $backupname.tar.gz 


popd
popd 

