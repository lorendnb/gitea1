#!/bin/bash
set -e
# Selecciona el nombre del container
CONTAINERNAME=giteaprod
TMPDIR=data

# Crea el directorio bkptmp
if [ ! -d $TMPDIR ]; then
  mkdir $TMPDIR
fi
pushd $TMPDIR

sudo rm -f *.*
sudo docker exec -i $CONTAINERNAME /app/gitea/gitea dump -c /data/gitea/conf/app.ini
sudo docker exec -i $CONTAINERNAME bash -c 'mv /gitea-dump*.zip /giteadump.zip'
sudo docker cp $CONTAINERNAME:/giteadump.zip .

# Obtiene el nombre de la imagen exacta que estamos usando
IMAGENAME=$(sudo docker ps -f "name=$CONTAINERNAME" --format "{{.Image}}") && echo $IMAGENAME
LINE="export IMAGENAME=$IMAGENAME"
echo $LINE >DockerParams.sh
LINE="export ORIGINALCONTAINERNAME=$CONTAINERNAME"
echo $LINE >>DockerParams.sh
COMANDO="zip $1 giteadump.zip DockerParams.sh"
echo "Executing: $COMANDO"
sudo $COMANDO
echo "Executed"
popd
