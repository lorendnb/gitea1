#!/bin/bash
#
# Use:
#   GITEA_BASE para el nombre base del GITEA. Default: gitea2
#	GITEA_PORT para el puerto. Default 30000
#   GITEA_SSH para el ssh del gitea: Default 30022
#   GITEA_IMAGE debe estar seteado con la imagen de gitea
#
BASENAME=${GITEA_BASE:-gitea2}
GITEAPORT=${GITEA_PORT:-30000}
GITEASSH=${GITEA_SSH:-30022}
GITEACONTAINER=$BASENAME
MYSQLCONTAINER=mysql$BASENAME
BASEDIR=$BASENAME

# Obtiene el nombre del zip
ZIPFILENAME=$1

#
# Borra el container
#

docker rm -f $GITEACONTAINER
# echo Waiting after remove
# sleep 5

sudo rm -rf /srv/$BASEDIR
sudo mkdir /srv/$BASEDIR

set -e

# Descomprime el .zip
unzip $ZIPFILENAME

# Descomprime el tar
sudo tar -xzvf backup_gitea.tar.gz -C /srv/$BASEDIR
rm backup_gitea.tar.gz

# Cambia el ownership del directorio
sudo chown 1000:1000 /srv/$BASEDIR

sudo chmod +x DockerParams.sh
source ./DockerParams.sh

rm DockerParams.sh

# Crea el container
COMANDO="docker run -tid --name $GITEACONTAINER -v /srv/$BASEDIR:/data -p $GITEAPORT:3000 -p $GITEASSH:22 $IMAGENAME"

echo "cmd: $COMANDO"
sudo $COMANDO

popd
